'use strict';
/**
 * 路由器配置DEMO 复制粘贴到state结尾语句后即可;
 * state('MainIndex.DEMO', {
                url:"/DEMO",
                controller: 'DEMOCtrl',
                templateUrl: '功能页面路径.html',
                css:[
                 	 'css/approval/css/main.css'
                     ,'css/approval/css/swiper.min.css'
                     ,'css/approval/css/popModal.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     //,'个性样式CSS文件.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'控制器js文件路径不含后缀名'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
 */
define(['router','appModule'], function () {
    var app = angular.module('systemApp');
    app.config(
        function($stateProvider, $urlRouterProvider,$httpProvider) {
        	$httpProvider.defaults.headers.post = {'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8'};
//        	$httpProvider.interceptors.push('sessionInjector');//自定义拦截器
        	$urlRouterProvider.otherwise('login');//如果没有指定路由,会默认访问login
        	$urlRouterProvider.when("", "/login");
            $stateProvider.
            state("MainIndex", {
                url: "/MainIndex",
                controller: 'MainIndexCtrl',
                templateUrl: "view/MainIdex/MainIndex.html",
                css:[
                     'css/animate/animate.min.css'
                 	 ,'css/approval/css/main.css'
                     ,'css/approval/css/swiper.min.css'
                     ,'css/approval/css/popModal.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     
                 ],
             resolve: {
                 loadCtrl: ["$q", function($q) {
                     var deferred = $q.defer();
                     //异步加载controller／directive/filter/service
                     require([
                      	'view/MainIdex/MainIndex.component'
                     ], function() { deferred.resolve(); });
                     return deferred.promise;
                 }]
             }
            }).
            state('login', {
                url:"/login",
                controller: 'loginCtrl',
                templateUrl: 'view/login/login.template.html',
                css: [
     			     'css/login/login.css'
     			     ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                            'view/login/login.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.main', {
                url:"/main",
                controller: 'mainCtrl',
                templateUrl: 'view/approval/main/main.template.html',
                css:[
                 	 'css/approval/css/main.css'
                     ,'css/approval/css/swiper.min.css'
                     ,'css/approval/css/popModal.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/main/main.component',
                            'view/approval/main/js/main',
                            'view/approval/main/js/popModal',
                            'view/approval/main/js/swiper.min'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.infoOperation', {
                url:"/infoOperation",
                controller: 'infoOperationCtrl',
                templateUrl: 'view/approval/infoOperation/infoOperation.template.html',
                css:[
                     'css/approval/font/iconfont.css'
                     ,'css/approval/css/main.css'
                     ,'css/approval/details/css/details.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/infoOperation/infoOperation.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.home', {
                url:"/home",
                controller: 'homeCtrl',
                templateUrl: 'view/system/home/home.template.html',
                css: ['css/app.css'
			        ,'css/main.css'
			        ,'css/ztree/zTreeStyle.css'
			        ,'components/tree/tree-control-attribute.css'
			        ,'components/tree/tree-control.css'
			        ,'css/animate/animate.min.css'
			        ,'css/fontawesome/css/font-awesome.min.css'
			        ,'css/simple-line-icons/css/simple-line-icons.css'
                    ,'css/approval/css/main.css'
  		        ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/home/home.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.user', {
                url:"/user",
                controller: 'userCtrl',
                templateUrl: 'view/system/user/user.template.html',
                css:['css/app.css'
 					,'css/main.css'
 					,'css/animate/animate.min.css'
 					,'css/fontawesome/css/font-awesome.min.css'
 					,'css/simple-line-icons/css/simple-line-icons.css'
                    ,'css/approval/css/main.css'
 				],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/user/user.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.group', {
                url:"/group",
                controller: 'groupCtrl',
                templateUrl: 'view/system/group/group.template.html',
                css:[
                     'css/app.css'
                     ,'css/main.css'
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/group/group.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.level', {
                url:"/level",
                controller: 'levelCtrl',
                templateUrl: 'view/system/level/level.template.html',
                css:[
                     'css/app.css'
                     ,'css/main.css'
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/level/level.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.fun', {
                url:"/fun",
                controller: 'funCtrl',
                templateUrl: 'view/system/fun/fun.template.html',
                css:[
                     'css/app.css'
                     ,'css/main.css'
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/fun/fun.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.product', {
                url:"/product",
                controller: 'productCtrl',
                templateUrl: 'view/system/product/product.template.html',
                css:[
  			       'css/app.css'
  				   ,'css/main.css'
  				   ,'css/animate/animate.min.css'
  				   ,'css/fontawesome/css/font-awesome.min.css'
  				   ,'css/simple-line-icons/css/simple-line-icons.css'
  				   ,'css/approval/css/main.css'
			    ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/product/product.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.parameter', {
                url:"/parameter",
                controller: 'parameterCtrl',
                templateUrl: 'view/system/parameter/parameter.template.html',
                css:[
                     'css/app.css'
                     ,'css/main.css'
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/parameter/parameter.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
//            //系统权限分配
//            state('MainIndex.systems', {
//                url:"/systems",
//                controller: 'systemsCtrl',
//                templateUrl: 'view/system/systems/systems.template.html',
//                css:[
//      		       'css/app.css'
//      		       ,'css/main.css'
//      		       ,'css/animate/animate.min.css'
//      		       ,'css/fontawesome/css/font-awesome.min.css'
//      		       ,'css/simple-line-icons/css/simple-line-icons.css'
//      		       ,'css/approval/css/main.css'
//      		    ],
//                resolve: {
//                    loadCtrl: ["$q", function($q) {
//                        var deferred = $q.defer();
//                        //异步加载controller／directive/filter/service
//                        require([
//                         	'view/system/systems/systems.component'
//                        ], function() { deferred.resolve(); });
//                        return deferred.promise;
//                    }]
//                }
//            }).
            state('MainIndex.organization', {
                url:"/organization",
                controller: 'organCtrl',
                templateUrl: 'view/system/organization/organization.template.html',
                css:[
                     'css/app.css'
                     ,'css/main.css'
                     ,'css/ztree/zTreeStyle.css'
  				     ,'components/tree/tree-control-attribute.css'
  				     ,'components/tree/tree-control.css'
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/system/organization/organization.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
             state('MainIndex.scanning', {//扫描
                url:"/scanning",
                controller: 'scanningCtrl',
                templateUrl: 'view/approval/scanning/scanning.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/scanning/scanning.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.finishScanning', {//扫描已完成
                url:"/finishScanning",
                controller: 'finishScanningCtrl',
                templateUrl: 'view/approval/finishScanning/finishScanning.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/finishScanning/finishScanning.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.detailFinishScanning', {//扫描已完成-详细
                url:"/detailFinishScanning",
                controller: 'detailFinishScanningCtrl',
                templateUrl: 'view/approval/finishScanning/detailFinishScanning/detailFinishScanning.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/finishScanning/detailFinishScanning/detailFinishScanning.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.fillScanning', {//待补扫
                url:"/fillScanning",
                controller: 'fillScanningCtrl',
                templateUrl: 'view/approval/fillScanning/fillScanning.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/fillScanning/fillScanning.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.detailFillScanning', {//待补扫-详细页面
                url:"/detailFillScanning",
                controller: 'detailFillScanningCtrl',
                templateUrl: 'view/approval/fillScanning/detailFillScanning/detailFillScanning.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/fillScanning/detailFillScanning/detailFillScanning.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.InputList', {//录入
                url:"/InputList",
                controller: 'InputListCtrl',
                templateUrl: 'view/approval/InputList/InputList.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/InputList/InputList.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.finishInputList', {//录入已完成
                url:"/finishInputList",
                controller: 'finishInputListCtrl',
                templateUrl: 'view/approval/finishInputList/finishInputList.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/finishInputList/finishInputList.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.waitingScanning', {//待重新录入
                url:"/waitingScanning",
                controller: 'waitingScanningCtrl',
                templateUrl: 'view/approval/waitingScanning/waitingScanning.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/waitingScanning/waitingScanning.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.examinList', {//文审
                url:"/examinList",
                controller: 'examinListCtrl',
                templateUrl: 'view/approval/examinList/examinList.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/examinList/examinList.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.examinDetai', {//文审处理
                url:"/examinDetai",
                controller: 'examinDetaiCtrl',
                templateUrl: 'view/approval/examinDetai/examinDetai.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                     ,'css/approval/details/css/details.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/examinDetai/examinDetai.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.finishExaminList', {//文审已完成
                url:"/finishExaminList",
                controller: 'finishExaminListCtrl',
                templateUrl: 'view/approval/finishExaminList/finishExaminList.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/finishExaminList/finishExaminList.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.creditList', {//征信
                url:"/creditList",
                controller: 'creditListCtrl',
                templateUrl: 'view/approval/creditList/creditList.template.html',
                css:[
					 ,'css/ztree/zTreeStyle.css'
					 ,'components/tree/tree-control-attribute.css'
					 ,'components/tree/tree-control.css'
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/creditList/creditList.component',
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.callCreditList', {//资信
                url:"/callCreditList",
                controller: 'callCreditListCtrl',
                templateUrl: 'view/approval/callCreditList/callCreditList.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/callCreditList/callCreditList.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            }).
            state('MainIndex.grantCreditList', {//授信
                url:"/grantCreditList",
                controller: 'grantCreditListCtrl',
                templateUrl: 'view/approval/grantCreditList/grantCreditList.template.html',
                css:[
                     
                     ,'css/animate/animate.min.css'
                     ,'css/fontawesome/css/font-awesome.min.css'
                     ,'css/simple-line-icons/css/simple-line-icons.css'
                     ,'css/approval/css/main.css'
                 ],
                resolve: {
                    loadCtrl: ["$q", function($q) {
                        var deferred = $q.defer();
                        //异步加载controller／directive/filter/service
                        require([
                         	'view/approval/grantCreditList/grantCreditList.component'
                        ], function() { deferred.resolve(); });
                        return deferred.promise;
                    }]
                }
            });
        });
    app.config(function($controllerProvider,$compileProvider,$filterProvider,$provide){
        app.register = {
            //得到$controllerProvider的引用
            controller : $controllerProvider.register,
            //同样的，这里也可以保存directive／filter／service的引用
            directive: $compileProvider.directive,
            filter: $compileProvider.register,
            factory:$provide.service,
            service: $provide.service
        };
    });
    app.config(function($sceProvider) {
  	  // 完全禁用SCE来支持IE7及以上版本。
  	  $sceProvider.enabled(false);
  	});
    return app;
});