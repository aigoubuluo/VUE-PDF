'use strict';
define(['appModule'], function () {
	// 定义“systemApp”模块
	angular.module('systemApp', [
	    'ui.router', 
	    'angularCSS',
	    'ngRoute',
	    'ngResource',
	    'ngCookies',
	    'ngSanitize',
	    'public.pagination',
	    'public.thumb',
	    'public.ztree',
	    'angularFileUpload',
	    'public.Echart',
	    'ngDialog'
	]);
});
