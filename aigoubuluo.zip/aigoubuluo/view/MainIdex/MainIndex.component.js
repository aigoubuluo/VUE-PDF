'use strict';
define(['app', 'appModule'],
function(app) {
    app.register.controller('MainIndexCtrl', ['$scope', '$rootScope', '$state', '$cookies', 'lodinDataService', '$location',
    function($scope, $rootScope, $state, $cookies, lodinDataService, $location) {
    	$scope.LoginList = lodinDataService.getObject('lodinData');
		$scope.loginOut = function(){
			$state.go('login');
		};
		$scope.cru = false;
		if($location.url()=='/MainIndex/main'){
			if(!$scope.switchStyle){
				$rootScope.wCru = false;
			}else{
				$rootScope.wCru = true;
			}
		}else if($location.url()=='/MainIndex/infoOperation'){
			$rootScope.wCru = false;
		}else{
			$scope.parentCru = lodinDataService.get('parentCru');
			$scope.childCru = lodinDataService.get('childCru');
			$rootScope.wCru = true;
			$scope.cru = true;
		}
		/*数据展示*/
    	$scope.login_branchId = $scope.LoginList.branchId;
    	$scope.login_userId = $scope.LoginList.userId;
    	$scope.login_employeeName = $scope.LoginList.employeeName;
    	$scope.login_logTime = $scope.LoginList.logTime;
    	$scope.login_positionName = $scope.LoginList.positionName;
    	$scope.login_branchName = $scope.LoginList.branchName;
    	/*数据展示end*/
		$scope.menuList = lodinDataService.getObject('menuList');
		
		//切换风格
		$scope.swich_button=true;
		$scope.swicth2 = false;
		$scope.switcha= function(){
			$rootScope.wCru=true;
			$scope.swicth2 = true;
			$scope.switchStyle =!$scope.switchStyle;
			$scope.switchStyletwo={'switchStyle':$scope.switchStyle};
    		lodinDataService.setObject("switchObjc",$scope.switchStyletwo);
    		$scope.swich_button=false;
			
		};
		
		//判断切换菜单
		$scope.switchObjc= lodinDataService.getObject('switchObjc');
		$scope.switchStyle=$scope.switchObjc.switchStyle;
		
		$scope.ishover = true;
		
     	$scope.switchtwo= function(e){ 
     		$cookies.MainfunName = "功能名称";
     		$cookies.MainfunUrl = "功能路径";
     		$cookies.MainparentFunId = "父功能ID";
     		$('.dropdown-menu').removeClass('active').addClass('inactive');
     		$rootScope.$broadcast('MainfunName',"功能名称");
     		$rootScope.$broadcast('MainparentFunId',"功能路径");
     		$rootScope.$broadcast('MainfunUrl',"父功能ID");
		};
	
        
        
        $scope.swicth_b = function(){
        	$scope.swicth2 = false;
        	$scope.swich_button=true;
        	$scope.switchStyle =!$scope.switchStyle;
			$scope.switchStyletwo={'switchStyle':$scope.switchStyle};
    		lodinDataService.setObject("switchObjc",$scope.switchStyletwo);
        	$('.container ').removeAttr('style');
        	$(".contenr_menu").removeClass('switch_contenr_menu').removeAttr('style');
			$('.right_container').removeClass('switct_contenr_right').removeAttr('style');
			$(".contenr_menu").removeClass('switch_contenr_menu2').removeAttr('style');
			$('.right_container').removeClass('switct_contenr_right2').removeAttr('style');
			$('.blue1').css('display','block');
			$('.blue2').css('display','block');

        };
        
//        	$(".switch_contenr_menu").height($('.switct_contenr_right').height()-10);
// 		    //当文档窗口发生改变时 触发  
// 		    $(window).resize(function(){  
// 		        $(".switct_contenr_right").height($('.switch_contenr_menu').height()-10);  
// 		    });
 		    //面包屑首页
 		    $scope.homeCru = function(){
 		    	if(!$scope.switchStyle){
 		    		$rootScope.wCru=false;
 		    		$scope.cru = false;
 		    	}else{
 		    		$scope.cru = false;
 		    	}
 		    };
 		    //面包屑一级二级
 		    $scope.chooseCru = function(e){
 		    	$rootScope.wCru = true;
 		    	$scope.cru = true;
 		    	$scope.parentCru = "父菜单功能名称";
 		    	$scope.childCru = "功能名称";
 		    	lodinDataService.set('parentCru',"父菜单功能名称");
 		    	lodinDataService.set('childCru',"功能名称");
 		    };
    }]);
});