'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('funCtrl', ['$scope',
    function($scope) {
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    }]);
});
