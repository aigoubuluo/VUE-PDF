'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('homeCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    	//弹出框显示隐藏
   	 	$scope.myModal_add = function(){
   	 	  $('#distribute').modal('hide');
   	 	  $('body').addClass("open_modal");
   	 	};
   		//选择机构取消编辑页
		$scope.dismiss = function(){
			$('#distribute').modal();
		};
		//功能分配取消编辑页
		$scope.dismiss1 = function(){
			$('#distribute').modal();
		};
    }]);
});
