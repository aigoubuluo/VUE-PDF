'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('productCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//（分页功能）
    	$scope.paginationConf = {
    	    currentPage: 1,
    	    totalItems: 3,
    	    itemsPerPage: 9,
    	    pagesLength: 5,
    	    perPageOptions: [9, 18, 27, 36, 45, 54, 63],
    	    onChange: function() {

    	}};
    	
    	//弹出层自适应居中
    	$(function() {
    	    $(".modal-body").height($(window).height() - 360);
    	    //当文档窗口发生改变时 触发  
    	    $(window).resize(function() {
    	        $(".modal-body").height($(window).height() - 360);
    	    });
    	    $(this).on('show.bs.modal',
    	    function() {
    	        $('body').addClass('modal-open');
    	    });
    	    $(this).on('hide.bs.modal',
    	    function() {
    	        $('body').removeClass('modal-open');
    	    });
    	});
    	
    	//文件上传控件1
    	var uploader1 = $scope.uploader1 = new FileUploader({
    	    url: '/FileServlet',
    	    //autoUpload:true
    	});
    	uploader1.filters.push({
    	    name: 'customFilter',
    	    fn: function(item
    	    /*{File|FileLikeObject}*/
    	    , options) {
    	        return this.queue.length < 1;
    	    }
    	});
    	$scope.click1 = function() {
    	    uploader1.queue = [];
    	    $("#fileb").click();
    	    console.log(uploader1.queue);
    	};
    	uploader1.onSuccessItem = function(fileItem, response, status, headers) {
    	    if (status == "200") {
    	        setTimeout(function() {
    	            $(".BeAlert_overlay,.BeAlert_box").remove();
    	        },
    	        1300);
    	        alert("上传成功!", "",
    	        function() {},
    	        {
    	            type: 'success',
    	            showConfirmButton: false
    	        });
    	        $scope.YESs = t1;
    	        $scope.YES = t2;
    	        $scope.imageSrc = response;
    	        $scope.filename = response;
    	        $scope.bizCardImagePc_add = response;
    	    } else {
    	        setTimeout(function() {
    	            $(".BeAlert_overlay,.BeAlert_box").remove();
    	        },
    	        2000);
    	        alert("上传失败!", "对不起，数据有误，上传失败!",
    	        function() {},
    	        {
    	            type: 'error',
    	            showConfirmButton: false
    	        });
    	    };
    	};
    	$scope.cancelup = function() {
    	    $scope.YESs = t2;
    	    $scope.YES = t1;
    	    $scope.imageSrc = "";
    	};

    	//文件上传控件2
    	var uploader2 = $scope.uploader2 = new FileUploader({
    	    url: '/FileServlet',
    	    //autoUpload:true
    	});
    	uploader2.filters.push({
    	    name: 'customFilter',
    	    fn: function(item
    	    /*{File|FileLikeObject}*/
    	    , options) {
    	        return this.queue.length < 10;
    	    }
    	});

    	uploader2.onSuccessItem = function(fileItem, response, status, headers) {
    	    if (status == "200") {
    	        setTimeout(function() {
    	            $(".BeAlert_overlay,.BeAlert_box").remove();
    	        },
    	        1300);
    	        alert("上传成功!", "",
    	        function() {},
    	        {
    	            type: 'success',
    	            showConfirmButton: false
    	        });
    	        $scope.YESs = t1;
    	        $scope.YES = t2;
    	        $scope.imageSrc2 = response;
    	        $scope.filename = response;
    	        $scope.bizCardImagePc_edit = response;
    	    } else {
    	        setTimeout(function() {
    	            $(".BeAlert_overlay,.BeAlert_box").remove();
    	        },
    	        2000);
    	        alert("上传失败!", "对不起，数据有误，上传失败!",
    	        function() {},
    	        {
    	            type: 'error',
    	            showConfirmButton: false
    	        });
    	    }
    	};
    }]);
});
