'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('userCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    }]);
});
