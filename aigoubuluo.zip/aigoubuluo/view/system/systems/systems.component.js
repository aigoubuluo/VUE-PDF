'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('funCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {}]);
    alert("已经加载当前页面控制器！");
});
