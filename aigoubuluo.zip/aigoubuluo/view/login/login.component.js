'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('loginCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	$scope.login = function() {
    		//判断切换风格
    		$scope.switchStyle={'switchStyle':false};
    		lodinDataService.setObject("switchObjc",$scope.switchStyle);
    		$state.go('MainIndex.main');
    	};
    }]);
});
