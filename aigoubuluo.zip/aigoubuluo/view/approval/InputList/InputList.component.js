'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('InputListCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    	//冻结列表单 页面中所用到的JS
    	var $table = $('#table');
        $(function () {
            buildTable($table, 20, 20);
            $('#fixedNumber').change(function () {
                buildTable($table, 20, 20);
            });
        });

        function buildTable($el, cells, rows) {
            var i, j, row,
                    columns = [],
                    data = [];

            for (i = 0; i < cells; i++) {
                columns.push({
                    field: 'field' + i,
                    title: 'Cell' + i,
                    sortable: true
                });
            }
            for (i = 0; i < rows; i++) {
                row = {};
                for (j = 0; j < cells; j++) {
                    row['field' + j] = 'Rows-' + i + '-' + j;
                }
                data.push(row);
            }
            $el.bootstrapTable('destroy').bootstrapTable({
                columns: columns,
                data: data,
                search: true,
                toolbar: '.toolbar',
                fixedColumns: true,
                pagination: true,
                pageSize: 5,                          
                pageList: [5, 10, 15, 20],
                fixedNumber: +$('#fixedNumber').val()
            });
        }
        
        //切换列表
        $scope.ccca = function() {
            alert("1");
            $(".switch_list").css('display', 'none');
            $(".switch_list_2").css('display', 'block');
        };
        $scope.cccb = function() {
            alert("2");
            $(".switch_list_2").css('display', 'none');
            $(".switch_list").css('display', 'block');
        };
    }]);
});