'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('detailFillScanningCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    	//附件上传功能上传
    	var uploader = $scope.uploader = new FileUploader({
    	    url: '',
    	    formData: [{'userId': $scope.appiAppId,}]
    	});
    	uploader.filters.push({
    	    name: 'customFilter',
    	    fn: function(item
    	    /*{File|FileLikeObject}*/
    	    , options) {
    	        return this.queue.length < 10;
    	    }
    	});

    	uploader.onSuccessItem = function(fileItem, response, status, headers) {
    	    $scope.imageUrl = response; //上传图片附件地址路径
    	    if (status == "200") {
    	    	setTimeout(function(){$(".BeAlert_overlay,.BeAlert_box").remove();},1300);
			    alert("上传成功!","", function () {}, {type: 'success',showConfirmButton:false});
    	        $scope.imageSrc2 = response;
    	        $scope.filename = response;
    	        $scope.bizCardImagePc_edit = response;
    	        var helper = {
    	            support: !!($window.FileReader && $window.CanvasRenderingContext2D),
    	            isFile: function(item) {
    	                console.log(item);
    	                return angular.isObject(item) && item instanceof $window.File;
    	            },
    	            isImage: function(file) {
    	                console.log(file);
    	                var type = '|' + file.type.slice(file.type.lastIndexOf('/') + 1) + '|';
    	                return '|jpg|png|jpeg|bmp|gif|'.indexOf(type) !== -1;
    	            }
    	        };

    	        return {
    	            restrict: 'A',
    	            template: '<canvas/>',
    	            link: function(scope, element, attributes) {
    	                if (!helper.support) return;

    	                var params = scope.$eval(attributes.ngThumb);

    	                if (!helper.isFile(params.file)) return;
    	                if (!helper.isImage(params.file)) return;

    	                var canvas = element.find('canvas');
    	                var reader = new FileReader();

    	                reader.onload = onLoadFile;
    	                reader.readAsDataURL(params.file);

    	                function onLoadFile(event) {
    	                    var img = new Image();
    	                    img.onload = onLoadImage;
    	                    img.src = event.target.result;
    	                };

    	                function onLoadImage() {
    	                    var width = params.width || this.width / this.height * params.height;
    	                    var height = params.height || this.height / this.width * params.width;
    	                    canvas.attr({
    	                        width: width,
    	                        height: height,
    	                    });
    	                    canvas[0].getContext('2d').drawImage(this, 0, 0, width, height);
    	                };
    	            }
    	        };
    	    } else {
    	        setTimeout(function() {$(".BeAlert_overlay,.BeAlert_box").remove();},2000);
    	        alert("上传失败!", "对不起，数据有误，上传失败!",function() {}, {type: 'error',showConfirmButton: false,});
    	    };
    	};        
    	//切换列表
        $scope.ccca = function() {
            alert("1");
            $(".switch_list").css('display', 'none');
            $(".switch_list_2").css('display', 'block');
        };
        $scope.cccb = function() {
            alert("2");
            $(".switch_list_2").css('display', 'none');
            $(".switch_list").css('display', 'block');
        };
    }]);
});