'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('infoOperationCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    	$scope.dealList = {};
    	$scope.dealList.isLook=$cookies.isLook;
    	$scope.dealList.nodeCode=$cookies.nodeCode;
    	console.log($scope.dealList.isLook+"==="+$scope.dealList.nodeCode);
    	$scope.dealList.appiAppId=$cookies.appiAppId;
    	$scope.userID = $scope.LoginList.userId;
    	$scope.branchID = $scope.LoginList.branchId;
    	$scope.appiName1 = $cookies.appiName;
    	$scope.appiMcIdNumber1 = $cookies.appiMcIdNumber;
    	$scope.nodeName1 =$cookies.nodeName;
    	$scope.bizTypeCode_load =  $cookies.bizTypeCode;
    	$rootScope.wCru = false;
    	$scope.goBack = function(){
    		$rootScope.wCru = true;
    	};
    	//初始模块加载
    	$('#needCheck_look input,#hedCheck_look input').attr("readonly", 'true');
    	$('#needCheck_look select,#hedCheck_look select').attr("disabled", 'true');
    	$('#needCheck_look textarea,#hedCheck_look textarea').attr("disabled", 'true');
    	$(".creditBack,.checkBack,.artiBack").css('display', 'none');

    	$('#detail_checkMEss input').attr("readonly", 'true');
    	$('#detail_checkMEss select').attr("disabled", 'true');
    	$('#detail_checkMEss textarea').attr("disabled", 'true');
    	$scope.rea = "no";
    	$scope.reb = "no";
    	$scope.rec = "no";
    	$scope.manCheck_look = "no";
    	//wyb
    	$(".checkClickEntry").css('display', 'block');
    	/////////录入页-处理
    	if ($scope.dealList.nodeCode == 1 && $scope.dealList.isLook == 1) {
    	    $(".credit_tab,.phone_tab,.arti_tab,.credit_tab_look,.phone_tab_look").css('display', 'none');
    	    $(".credit_pop,.entry_detail_list,.patch_notice,.break_up_reject,.edti_change").css('display', 'none');
    	    $("#hedCheck,#needCheck,#manCheck,#needCheck_look,#manCheck_look").css('display', 'none');

    	}
    	/////////补录页-处理
    	if ($scope.dealList.nodeCode == 4 && $scope.dealList.isLook == 1) {
    	    $(".entry_tab,.phone_tab,.arti_tab,.credit_tab_look,.phone_tab_look").css('display', 'none');
    	    $(".patch_notice,.break_up_reject").css('display', 'none');
    	    $(".entry_all,#needCheck,#manCheck,#needCheck_look,#manCheck_look").css('display', 'none');
    	    $("#hedCheck,.credit_tab").css('display', 'block');
    	    $scope.rea = ok;
    	    $scope.editToggle1 = function() {
    	        $(".credit_mess,.entry_submit,.artiback").css("display", "none");
    	        $(".entry_all,.creditBack").css("display", "block");
    	        $(".checkClickEntry").css("display", "none");
    	    };
    	    $scope.creditBack = function() {
    	        $(".entry_all,.creditBack").css("display", "none");
    	        $(".credit_mess,.entry_submit").css("display", "block");
    	    };
    	}

    	/////////电话核查页-处理
    	if ($scope.dealList.nodeCode == 6 && $scope.dealList.isLook == 1) {
    	    $(".credit_tab,.entry_tab,.arti_tab,.phone_tab_look").css('display', 'none');
    	    $(".entry_all,#hedCheck,#manCheck,#needCheck_look").css('display', 'none');
    	    $(".pic_remake").css('display', 'none');
    	    $("#needCheck").addClass("active");
    	    $scope.reb = ok;
    	    $scope.editToggle2 = function() {
    	        $(".phone_mess,.entry_submit,.artiback").css("display", "none");
    	        $(".entry_all,.checkBack").css("display", "block");
    	        $(".checkClickEntry").css("display", "none");
    	    };

    	    $scope.checkBack = function() {
    	        $(".entry_all,.checkBack").css("display", "none");
    	        $(".phone_mess,.entry_submit").css("display", "block");
    	    };
    	}

    	/////////人工授额页-处理
    	if ($scope.dealList.nodeCode == 10 && $scope.dealList.isLook == 1) {
    	    $(".credit_tab,.entry_tab,.phone_tab").css('display', 'none');
    	    $(".entry_all,#hedCheck,#needCheck").css('display', 'none');
    	    $(".pic_remake").css('display', 'none');
    	    $(".checkClickEntry").css('display', 'none');
    	    $("#manCheck").addClass("active");
    	    $scope.rec = "ok";

    	    $scope.editToggle3 = function() {
    	        $(".arit_mess,.entry_submit").css("display", "none");
    	        $(".entry_all,.artiBack").css("display", "block");
    	        $(".checkClickEntry").css("display", "none");
    	    };
    	    $scope.artiback = function() {
    	        $(".entry_all,.artiBack").css("display", "none");
    	        $(".arit_mess,.entry_submit").css("display", "block");
    	    };
    	};
    }]);
});