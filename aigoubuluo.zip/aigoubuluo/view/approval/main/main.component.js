'use strict';
define(['app', 'appModule'],
function(app) {
    app.register.controller('mainCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	//汉字转拼音
    	$scope.pinyin = function(name){
    		$scope.pinyinData = pinyin.getFullChars(name);
    	};
    	//通过身份证号码获取更多信息
    	$scope.testClick = function(){
    		$scope.age = age;
    		$scope.province = province;
    		 if (sex!=undefined&&province!=undefined&&sex!=undefined) {
    			 if (sex=='man') {
	    			$scope.sex = "男";
				}else if(sex=='woman'){
					$scope.sex = "女";
				}
    			alert("<b style='color: #59B7BD;'>年龄：</b>"+$scope.age+"；&emsp;&emsp;"+"<br/>"+"<b style='color: #59B7BD;'>省份：</b>"+$scope.province+"；"+"<br/>"+"<b style='color: #59B7BD;'>性别：</b>"+$scope.sex+"；&emsp;&emsp;");
			} else {
				alert("请填写正确证件号码！");
			}
    	};
    	//冻结列表单 页面中所用到的JS
    	var $table = $('#table');
        $(function () {
            buildTable($table, 20, 20);
            $('#fixedNumber').change(function () {
                buildTable($table, 20, 20);
            });
        });

        function buildTable($el, cells, rows) {
            var i, j, row,
                    columns = [],
                    data = [];

            for (i = 0; i < cells; i++) {
                columns.push({
                    field: 'field' + i,
                    title: 'Cell' + i,
                    sortable: true
                });
            }
            for (i = 0; i < rows; i++) {
                row = {};
                for (j = 0; j < cells; j++) {
                    row['field' + j] = 'Rows-' + i + '-' + j;
                }
                data.push(row);
            }
            $el.bootstrapTable('destroy').bootstrapTable({
                columns: columns,
                data: data,
                search: true,
                toolbar: '.toolbar',
                fixedColumns: true,
                pagination: true,
                pageSize: 10,                          
                pageList: [10, 25, 50, 100],
                fixedNumber: +$('#fixedNumber').val()
            });
        }
        
///////////////////////华丽分隔符\\\\\\\\\\\\\\\\\\\\\\\\\\
    	$scope.statistics = true;
        if (!$scope.switchStyle) {
            $rootScope.wCru = false;
        } else {
            $rootScope.wCru = true;
        }
        //图表工具 star
        $scope.option1 = {
    		 tooltip : {
    		        trigger: 'axis',
    		        axisPointer : {            // 坐标轴指示器，坐标轴触发有效
    		            type : 'shadow'        // 默认为直线，可选为：'line' | 'shadow'
    		        }
    		    },
    		    legend: {
    		        data:['直接访问','邮件营销','联盟广告','视频广告','搜索引擎','百度','谷歌','必应','其他']
    		    },
    		    toolbox: {
    		        show : true,
    		        orient: 'vertical',
    		        x: 'right',
    		        y: 'center',
    		        feature : {
    		            mark : {show: true},
    		            dataView : {show: true, readOnly: false},
    		            magicType : {show: true, type: ['line', 'bar', 'stack', 'tiled']},
    		            restore : {show: true},
    		            saveAsImage : {show: true}
    		        }
    		    },
    		    calculable : true,
    		    xAxis : [
    		        {
    		            type : 'category',
    		            data : ['周一','周二','周三','周四','周五','周六','周日']
    		        }
    		    ],
    		    yAxis : [
    		        {
    		            type : 'value'
    		        }
    		    ],
    		    series : [
    		        {
    		            name:'直接访问',
    		            type:'bar',
    		            data:[320, 332, 301, 334, 390, 330, 320]
    		        },
    		        {
    		            name:'邮件营销',
    		            type:'bar',
    		            stack: '广告',
    		            data:[120, 132, 101, 134, 90, 230, 210]
    		        },
    		        {
    		            name:'联盟广告',
    		            type:'bar',
    		            stack: '广告',
    		            data:[220, 182, 191, 234, 290, 330, 310]
    		        },
    		        {
    		            name:'视频广告',
    		            type:'bar',
    		            stack: '广告',
    		            data:[150, 232, 201, 154, 190, 330, 410]
    		        },
    		        {
    		            name:'搜索引擎',
    		            type:'bar',
    		            data:[862, 1018, 964, 1026, 1679, 1600, 1570],
    		            markLine : {
    		                itemStyle:{
    		                    normal:{
    		                        lineStyle:{
    		                            type: 'dashed'
    		                        }
    		                    }
    		                },
    		                data : [
    		                    [{type : 'min'}, {type : 'max'}]
    		                ]
    		            }
    		        },
    		        {
    		            name:'百度',
    		            type:'bar',
    		            barWidth : 5,
    		            stack: '搜索引擎',
    		            data:[620, 732, 701, 734, 1090, 1130, 1120]
    		        },
    		        {
    		            name:'谷歌',
    		            type:'bar',
    		            stack: '搜索引擎',
    		            data:[120, 132, 101, 134, 290, 230, 220]
    		        },
    		        {
    		            name:'必应',
    		            type:'bar',
    		            stack: '搜索引擎',
    		            data:[60, 72, 71, 74, 190, 130, 110]
    		        },
    		        {
    		            name:'其他',
    		            type:'bar',
    		            stack: '搜索引擎',
    		            data:[62, 82, 91, 84, 109, 110, 120]
    		        }
    		    ]
    		};
        //图表工具 End

        //（分页功能）
        $scope.paginationConf = {
            currentPage: 1,
            totalItems: 3,
            itemsPerPage: 9,
            pagesLength: 5,
            perPageOptions: [9, 18, 27, 36, 45, 54, 63],
            onChange: function() {

            }};

        // 列表查询（分页功能）
        //	$scope.paginationConf = {
        //		currentPage : 1,
        //		totalItems : 10,
        //		itemsPerPage : 9,
        //		pagesLength : 5,
        //		perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
        //		onChange : function() {
        //			var gro = ($scope.paginationConf.currentPage - 1)* ($scope.paginationConf.itemsPerPage);
        //			var BusinessUr22 = new businessUrl(
        //					{
        //						"transCode" : "A000116",
        //						"indexNo" : gro + 1,
        //						"pageSize" : $scope.paginationConf.itemsPerPage,
        //						'tuserId' : $scope.login_userId,
        //						'searchDate':$scope.timeDates,
        //						//'completeState':$scope.works,
        //						//wyb  将默认查询所有件修改为 默认查询未完成的件
        //						'completeState':'unfinish',
        //						'nodeCode':$scope.funs
        //					});
        //				BusinessUr22.$save(function(objc) {
        //					if (objc.returnMsg=="查无此数据") {
        //						setTimeout(function(){$(".BeAlert_overlay,.BeAlert_box").remove();},2000);
        //						alert("温馨提示!","没有检索到相关数据", function () {}, {type: 'warning',showConfirmButton:false});
        //					} else {
        //						$scope.handle = true;
        //						$scope.queryList = objc.rows;
        //						if($scope.queryList!=''){
        //							for(var i = 0;i<3;i++){
        //								 var c = "show_jia"+i;
        //								 var d = "show_eys"+i;
        //								 var g = "dealBtn"+i;
        //								 $scope[c] = false;
        //								 $scope[d] = true;
        //								 $scope.handle = false;
        //								 $scope.achieve = false;
        //								 $scope[g] = true;
        //							} 
        //						page = objc.totalCount;
        //						$scope.paginationConf.totalItems = page; 
        //						//wyb
        //						for (var j = 0; j < $scope.queryList.length; j++) {
        //							var m = "show_jia"+j;
        //							var s = "show_eys"+j;
        //							var l = "dealBtn"+j;
        //							$scope.queryList[j].state;
        //							$scope.appiAppIdAdd = $scope.queryList[j].appiAppId;
        //							//$scope.show_jia = false;
        //							if($scope.queryList[j].state  == '0'){
        //								$scope[m] = false;
        //								$scope[s] = true;
        //								$scope.handle = true;
        //								$scope.achieve = false;
        //								$scope[l] = true;
        //							}else if( $scope.queryList[j].state == '1' ){
        //								$scope[m] = false;
        //								$scope.isSelected = true;
        //								$scope[s] = false;
        //								$scope[l] = false;
        //								$scope.achieve = false;
        //								$scope.dealBtn = false;
        //							} else if( $scope.queryList[j].state == '2'){
        //								$scope.nodeStatus = $scope.queryList[j].nodeCode;
        //								$scope[m]= true;
        //								$scope[s]= true;
        //								$scope.isSelected = true;
        //								$scope.handle = false;
        //								$scope.achieve = false;
        //								$scope[l] = false;
        //							} 
        //							else if( $scope.queryList[j].state == '3'){
        //								$scope[l] = false;
        //								$scope[m] = false;
        //								$scope[s] = true;
        //							}
        //						}
        //					}
        //				}
        //			});
        //		}
        //	};
        //点击处理
        $scope.entry_deal = function(e) {
            $cookies.isLook = 1;
            $cookies.appiName = "";
            $cookies.appiAppId = "";
            $cookies.nodeCode = 1;
            $cookies.nodeName = "";
            $cookies.bizTypeCode = "";
            $state.go('MainIndex.infoOperation');
        };
        //点击查看
        $scope.entry_look = function(e) {
            $cookies.isLook = 1;
            $cookies.appiName = "";
            $cookies.appiMcIdNumber = "";
            $cookies.nodeName = "";
            $cookies.bizTypeCode = "";
            $cookies.nodeCode = 10;
            $cookies.appiAppId = "";
            $state.go('MainIndex.infoOperation');
        };
        ///////////时间控件////////
        layui.use('laydate',
        function() {
            var laydate = layui.laydate;
            var start = {
                //min: laydate.now()
                max: '2099-06-16 23:59:59',
                istoday: false,
                choose: function(datas) {
                    $scope.startDate = datas;
                    end.min = datas; //开始日选好后，重置结束日的最小日期
                    end.start = datas //将结束日的初始值设定为开始日
                }
            };

            var end = {
                //min: laydate.now()
                max: '2099-06-16 23:59:59',
                istoday: false,
                choose: function(datas) {
                    $scope.endDate = datas;
                    start.max = datas; //结束日选好后，重置开始日的最大日期
                }
            };
            document.getElementById('LAY_demorange_s').onclick = function() {
                start.elem = this;
                laydate(start);
            };
            document.getElementById('LAY_demorange_e').onclick = function() {
                end.elem = this;
                laydate(end);
            };
        });
        ///////////时间控件end////////
        //切换列表
        $scope.ccca = function() {
            alert("1");
            $(".switch_list").css('display', 'none');
            $(".switch_list_2").css('display', 'block');
        };
        $scope.cccb = function() {
            alert("2");
            $(".switch_list_2").css('display', 'none');
            $(".switch_list").css('display', 'block');
        };
    }]);
});