// JavaScript Document
function ccc(){
    	
        var is_bouncy_nav_animating = false;
        
        //弹出菜单
    $('.cd-bouncy-nav-trigger').click(function(index){
        var i = $(".cd-bouncy-nav-trigger").index(this);
         triggerBouncyNav2(true,i);
    });
        //关闭菜单
        $('.cd-bouncy-nav-modal .cd-close').on('click', function() {

            triggerBouncyNav(false);
        });
    	
        $('.cd-bouncy-nav-modal').on('click', function(event) {
    	   
            if ($(event.target).is('.cd-bouncy-nav-modal')) {
                triggerBouncyNav(false);
            }
        });
    	
         function triggerBouncyNav($bool) {
            //点击若没有动画
            if (!is_bouncy_nav_animating) {
                is_bouncy_nav_animating = true;
                //切换菜单动画
                $('.cd-bouncy-nav-modal').toggleClass('fade-in', $bool).toggleClass('fade-out', !$bool).find('li:last-child').one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function() {
                    $('.cd-bouncy-nav-modal').toggleClass('is-visible', $bool);
                    if (!$bool)
                        $('.cd-bouncy-nav-modal').removeClass('fade-out');
                    is_bouncy_nav_animating = false;
                });
                //判断css 动画是否开启.. 
                if ($('.cd-bouncy-nav-trigger').parents('.no-csstransitions').length > 0) {
                    $('.cd-bouncy-nav-modal').toggleClass('is-visible', $bool);
                    is_bouncy_nav_animating = false;
                }
            }
        }
        function triggerBouncyNav2($bool,i) {

            var obj = $('.cd-bouncy-nav-modal').eq(i);
            //点击若没有动画
            if (!is_bouncy_nav_animating) {
                is_bouncy_nav_animating = true;
                //切换菜单动画
                obj.toggleClass('fade-in', $bool).toggleClass('fade-out', !$bool).find('li:last-child').one('webkitAnimationEnd oanimationend msAnimationEnd animationend', function() {
                    obj.toggleClass('is-visible', $bool);
                    if (!$bool)
                        obj.removeClass('fade-out');
                    is_bouncy_nav_animating = false;
                });
                //判断css 动画是否开启.. 
                if ($('.cd-bouncy-nav-trigger').parents('.no-csstransitions').length > 0) {
                    obj.toggleClass('is-visible', $bool);
                    is_bouncy_nav_animating = false;
                }
            }
        }
    	 $(document).mouseover(function(event){
              var _con = $('.cd-bouncy-nav-modal');   // 设置目标区域
    		  if(!_con.is(event.target) && _con.has(event.target).length === 0){ // Mark 1
    			//$('#divTop').slideUp('slow');   //滑动消失
    			 triggerBouncyNav(false);      //淡出消失
    			 is_bouncy_nav_animating = false;
    			 is_bouncy_nav_animating = false;
    		  }
        });
    }

//标识提醒
$(function () { $("[data-toggle='tooltip']").tooltip(); });
//弹出框
$(function () 
     { $("[data-toggle='popover']").popover();
     });
/* $(document).ready(function(){  
   $('.cd-bouncy-nav-trigger').click(function (event) {  
         //取消事件冒泡   
         //按钮的toggle,如果div是可见的,点击按钮切换为隐藏的;如果是隐藏的,切换为可见的。  
         $('.fade-in').toggle('slow');  
		 return false;
     }); 
     //点击空白处隐藏弹出层，下面为滑动消失效果和淡出消失效果。
	 $(document).mouseover(function(event){
		  var _con = $('.fade-in');   // 设置目标区域
		  if(!_con.is(event.target) && _con.has(event.target).length === 0){ // Mark 1
			//$('#divTop').slideUp('slow');   //滑动消失
			$('.fade-in').hide();          //淡出消失
		  }
	});
 })*/
//置顶菜单