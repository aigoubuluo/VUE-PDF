'use strict';
define(['app','appModule'],
function(app) {
    app.register.controller('finishInputListCtrl', ['$scope', '$rootScope', '$state', '$cookies', '$timeout', '$cookieStore', 'businessUrl', 'coreUrl', '$filter', 'lodinDataService', 'lodinDatadService', 'FileUploader',
    function($scope, $rootScope, $state, $cookies, $timeout, $cookieStore, businessUrl, coreUrl, $filter, lodinDataService, lodinDatadService, FileUploader) {
    	
    	//汉字转拼音
    	$scope.pinyin = function(name){
    		$scope.pinyinData = pinyin.getFullChars(name);
    	};
    	
    	$scope.statistics = true;
        if (!$scope.switchStyle) {
            $rootScope.wCru = false;
        } else {
            $rootScope.wCru = true;
        }
    	//（分页功能）
    	$scope.paginationConf = {
    			currentPage : 1,
    			totalItems : 3,
    			itemsPerPage : 9,
    			pagesLength : 5,
    			perPageOptions : [ 9, 18, 27, 36, 45, 54, 63 ],
    			onChange : function() {
    				
    			}};
    	
        //切换列表
        $scope.ccca = function() {
            alert("1");
            $(".switch_list").css('display', 'none');
            $(".switch_list_2").css('display', 'block');
        };
        $scope.cccb = function() {
            alert("2");
            $(".switch_list_2").css('display', 'none');
            $(".switch_list").css('display', 'block');
        };
        //日期控件
        layui.use('laydate',
                function() {
                    var laydate = layui.laydate;
                    var start = {
                        //min: laydate.now()
                        max: '2099-06-16 23:59:59',
                        istoday: false,
                        choose: function(datas) {
                            $scope.startDate = datas;
                            end.min = datas; //开始日选好后，重置结束日的最小日期
                            end.start = datas //将结束日的初始值设定为开始日
                        }
                    };

                    var end = {
                        //min: laydate.now()
                        max: '2099-06-16 23:59:59',
                        istoday: false,
                        choose: function(datas) {
                            $scope.endDate = datas;
                            start.max = datas; //结束日选好后，重置开始日的最大日期
                        }
                    };
                    document.getElementById('LAY_demorange_s').onclick = function() {
                        start.elem = this;
                        laydate(start);
                    };
                    document.getElementById('LAY_demorange_e').onclick = function() {
                        end.elem = this;
                        laydate(end);
                    };
                });
    }]);
});