/**
 * name: public.ztree
 * Version: 1.0.0 beta
 */
define(['publicZtree'],
function() {
    angular.module('public.ztree', []).directive('checkofftree', [function() {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function($scope, element, attrs, ngModel) {
                var setting = {
                    check: {
                        enable: false,
                    },
                    data: {
                        key: {
                            title: "branchName"
                        },
                        simpleData: {
                            enable: true
                        }
                    },
                    callback: {
                        onClick: function(event, treeId, treeNode, clickFlag) {
                            BRANCHID = treeNode.branchId;
                            BRANCHIDName = treeNode.branchName;
                            $scope.$apply(function() {
                                ngModel.$setViewValue(treeNode);
                            });
                        }
                    },
                };

                //向控制器发送消息，进行菜单数据的获取 
                $scope.$emit("treeCtrl", attrs["1"]);
                $scope.$on("treeData",
                function(event, data) { //监听或接收数据。。用于接收event与data
                    $.fn.zTree.init($("#onetree"), setting, data); //进行初始化树形菜单 
                    //$.fn.zTree.init(element, setting, data);//进行初始化树形菜单 element
                    var zTree = $.fn.zTree.getZTreeObj("onetree"); //zTree 的 DOM 容器的 id
                    var selectName = $("#selectName").val();
                    if (typeof selectName == "undefined" || selectName == "") {
                        zTree.selectNode(zTree.getNodeByParam("onetree", "1")); //默认第一个选中 
                        $("#selectName").val(zTree.getSelectedNodes()[0]); //赋值 
                    } else {
                        for (var i = 0; i < data.length; i++) {
                            if (data[i]["branchId"] == selectName) {
                                zTree.selectNode(zTree.getNodeByParam("branchId", data[i]["branchId"]));
                            }
                        }
                    }
                });
            }
        };
    }]).directive('checkontree', [function() {
        return {
            require: 'ngModel',
            restrict: 'A',
            link: function($scope, element, attrs, ngModel) {
                var setting = {
                    check: {
                        enable: true,
                    },
                    data: {
                        key: {
                            title: "branchName"
                        },
                        simpleData: {
                            enable: true
                        }
                    },
                    callback: {
                    	onCheck: function(event, treeId, treeNode) {
                    		var resultTree = '';
            				var result_Edit = '';
            				if(treeId == "towtree"){// 新增任务分派时选择的树
            					var treeObj = $.fn.zTree.getZTreeObj("towtree");
            					var nodes = treeObj.getCheckedNodes(true);
            					for( var i = 0; i < nodes.length; i++){
            						resultTree += nodes[i].branchName+nodes[i].branchId + ',';
            					}
            					resultTree = resultTree.substr(0, resultTree.length - 1);
            					resultTreeA = resultTree;
            				}else if(treeId == "treeEdit"){// 修改任务分派时选择的树
            					var treeObj = $.fn.zTree.getZTreeObj("treeEdit");
            					var nodes = treeObj.getCheckedNodes(true);
            					for( var i = 0; i < nodes.length; i++){
            						result_Edit += nodes[i].branchName+nodes[i].branchId + ',';
            					}
            					result_Edit = result_Edit.substr(0, result_Edit.length - 1);
            					resultTreeA = result_Edit;
            				}
                    	}
                    },
                };

                //向控制器发送消息，进行菜单数据的获取 
                $scope.$emit("treeCtrl", attrs["1"]);
                $scope.$on("treeData",
                function(event, data) { //监听或接收数据。。用于接收event与data
                    $.fn.zTree.init($("#towtree"), setting, data); //进行初始化树形菜单 
                    //$.fn.zTree.init(element, setting, data);//进行初始化树形菜单 element
                    var zTree = $.fn.zTree.getZTreeObj("towtree"); //zTree 的 DOM 容器的 id
                    var selectName = $("#selectName").val();
                    if (typeof selectName == "undefined" || selectName == "") {
                        zTree.selectNode(zTree.getNodeByParam("towtree", "1")); //默认第一个选中 
                        $("#selectName").val(zTree.getSelectedNodes()[0]); //赋值 
                    } else {
                        for (var i = 0; i < data.length; i++) {
                            if (data[i]["branchId"] == selectName) {
                                zTree.selectNode(zTree.getNodeByParam("branchId", data[i]["branchId"]));
                            }
                        }
                    }
                });
            }
        };
    }]);
});