define(['indexRun','appModule'], function () {
  'use strict';

  angular
    .module('systemApp')
    .run(checkPermission);

  /** @ngInject */
  
  /**
   * angular-permission version 3.0.x.
   * https://github.com/Narzerus/angular-permission/wiki/Managing-permissions.
   * 
   * 第一步: 运行authService.getAuthenticationParams()函数.
   * 返回true：用户之前成功登陆过。因而localStorage中已储存isAuth和authtoken两个参数。 
   * 返回false：用户或许已logout，或是首次访问应用。因而强制用户至登录页输入用户名密码登录。
   *
   * 第二步: 运行authService.checkAuthentication()函数.
   * 返回true：用户的token依旧有效，同时用户依然拥有admin权限。因而无需手动登录，页面将自动重定向到admin页面。
   * 返回false：要么用户token已经过期，或用户不再属于admin权限。因而强制用户至登录页输入用户名密码登录。
   */
  function checkPermission(PermissionStore,$http,lodinDataService) {
//	  alert("初始化最外层验证sessionId是否为空==="+PermissionStore.getItem("sessionId"))
	  if(PermissionStore.getItem("sessionId")==null){
		  $http.post("/").success(function(data,status,response) {
//		      	alert("初始化接口返回data==="+JSON.stringify(data))
		      	if(data.returnCode==101){
//		      		alert("初始化returnCode==101")
//		      		 location.href="#/home"
		      	}else{
//		      		location.href="#/login"
//		      		alert("初始化验证失败")
		      	}
		      }).error(function(error) {
//		        alert("验证接口最后error==="+JSON.stringify(error))
		      });
	  };
  };
});