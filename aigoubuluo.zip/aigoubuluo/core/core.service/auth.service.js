define(['authService','appModule'], function () {
	'use strict';
	// 创建本地存储仓库
	angular.module('systemApp').factory("PermissionStore", function() {
		this.clearStore = function() {
			if (sessionStorage) {
				sessionStorage.clear();
			}
		}
		this.setItem = function(key, value) {
			if (sessionStorage) {
				sessionStorage.setItem(key, value);
			}
		}
		this.getItem = function(key) {
			if (sessionStorage) {
				return sessionStorage.getItem(key);
			}
			return null;
		}
		this.definePermission = function(key, value) {
			this.setItem(key, value);
		}
		return this;
	});
	// 创建本地存储仓库
	angular.module('systemApp').factory("loginStorage", ['$window',function($window) {
		return{        
		 	//存储单个属性
	        set :function(key,value){
	          $window.localStorage[key]=value;
	        },        
	        //读取单个属性
	        get:function(key,defaultValue){
	          return  $window.localStorage[key] || defaultValue;
	        },        
	        //存储对象，以JSON格式存储
	        setObject:function(key,value){
	          $window.localStorage[key]=JSON.stringify(value);
	        },        
	        //读取对象
	        getObject: function (key) {
	          return JSON.parse($window.localStorage[key] || '{}');
	        }

	      }
}])
});