define(['authInterceptorService','appModule'], function () {
	'use strict';
	angular.module('systemApp').factory('sessionInjector', ["$q","$rootScope",function ($q,$rootScope) {
		var sessionInjector = {
	        request:function(config){
	            config.headers["userInfo"] = $rootScope.sessionId+"|"+$rootScope.landingName+"|"+window.location.hash;
//	            alert("自定义拦截器$rootScope.sessionId===="+$rootScope.sessionId);
	            return config;
	        },
	        responseError: function (data) {
//	        	alert("自定义拦截器错误返回===="+JSON.stringify(data))
				// 判断错误码，如果是未登录
	            if(data["errorCode"] == "500999"){
					// 清空用户本地token存储的信息，如果
	                $rootScope.user = {token:""};
					// 全局事件，方便其他view获取该事件，并给以相应的提示或处理
	                $rootScope.$emit("userIntercepted","notLogin",response);
	            }
				// 如果是登录超时
				if(data["errorCode"] == "500998"){
	                $rootScope.$emit("userIntercepted","sessionOut",response);
	            }
	            return $q.reject(response);
	        }
	    };
		return sessionInjector;
	}]);
	
});