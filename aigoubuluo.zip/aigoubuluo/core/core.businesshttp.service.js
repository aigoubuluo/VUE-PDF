'use strict';
/**
 * 请求地址简单封装
 * 控制器当中只需要注入“businessUrl”即可调用到当前文件中的访问地址
 * 调取方式如下（此段代码请在控制器中使用）：
	var demoUrl = new businessUrl({
		"transCode":"B000200",//交易码
		"parameter":"parameterData",//所需要上传的参数
	});
	demoUrl.$save(function(objc){
		console.log(objc);
	},function(error){
	   console.log(error); 
	});
 */
define(['businesshttpService','appModule'], function () {
angular.
	module('systemApp').
	factory('businessUrl', ['$resource',function($resource) {
      return $resource('/jsonHttpServlet?channelNo=1');
    }
  ]);
});