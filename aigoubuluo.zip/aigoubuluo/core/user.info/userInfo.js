var app = angular.module('user.info', []);

app.factory('User', function($http, $q, $timeout,ENV,$rootScope,PermissionStore){
    var userInfo, 
        loading, 
        deferred = $q.defer(),
        promise  = deferred.promise;
    return {
        getUserInfo: function(scope){
            if(!loading){
                loading = true;
                
                
                $rootScope.sessionId = PermissionStore.getItem('sessionId');
				$rootScope.roles = PermissionStore.getItem('roles');
				$rootScope.userName = PermissionStore.getItem('userName');
				
				
                var user = {};
                var that = scope;
//                $timeout(function(){
//                    var userInfo = that.user;
//                    deferred.resolve(userInfo);
//                }, 100);
                return promise;
            }else if( userInfo ){
                console.log('这是缓存的信息');
                return $q.resolve(userInfo);
            }else{
                console.log('正在等待请求的结果...');
                return promise;
            }
        }($rootScope)
    }
});