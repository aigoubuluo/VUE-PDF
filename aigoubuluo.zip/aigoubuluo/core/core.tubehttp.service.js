'use strict';
/**
 * 请求地址简单封装
 * 控制器当中只需要注入对应的“postParamUrl”即可调用到当前文件中的POST请求地址，同理注入对应的“getParamUrl”即可调用到当前文件中的Get请求地址
 * 调取方式如下（此段代码请在控制器中使用）：
	
	测试案例
	发送POST请求实例
	var PostParamUrl = new postParamUrl({"POSTdata":"POSTPOSTdata001"});
	PostParamUrl.$save({className: "POSTclassName",funName:"POSTfunName"},function(res){
		$scope.prod2 = res;
		console.log(prod2);
	},function(error){
        console.log(error);
    })
	
 	测试案例
	发送Get请求实例
	getParamUrl.query({className: "GetclassName",funName:"GetfunName","Getdata1":"Getdata001","Getdata2":"Getdata002"},function(resp){
		$scope.prod3 = resp;
		console.log(prod3);
    },function(error){
        console.log(error);
    });
 */
define(['tubehttpService','appModule'], function () {
angular.
	module('systemApp').
	  /**
	   * 参数post请求封装
	   */
	  factory('coreUrl', ['$resource',function($resource) {
	      return $resource('http://10.6.10.212:8090/CORE_PARAM_SERVER/ws/:className/:funName',{className: '@postParamclassName', funName: '@postParamfunName'});
	    }
	  ]).
	  /**
	   * 参数get请求封装
	   */
	  factory('getCoreUrl', ['$resource',function($resource) {
	      return $resource('http://10.6.10.212:8090/CORE_PARAM_SERVER/ws/:className/:funName',{className: '@getParamclassName', funName: '@getParamfunName'});
	    }
	  ]).
	  /**
	   * 参数post请求封装
	   */
	  factory('postParamUrl', ['$resource',function($resource) {
	      return $resource('http://10.6.10.212:8090/CORE_PARAM_SERVER/ws/:className/:funName',{className: '@postParamclassName', funName: '@postParamfunName'});
	    }
	  ]).
	  /**
	   * 参数get请求封装
	   */
	  factory('getParamUrl', ['$resource',function($resource) {
	      return $resource('http://10.6.10.212:8090/CORE_PARAM_SERVER/ws/:className/:funName',{className: '@getParamclassName', funName: '@getParamfunName'});
	    }
	  ]).
	  /**
	   * 角色post请求封装
	   */
	  factory('postAuthUrl', ['$resource',function($resource) {
	      return $resource('http://127.0.0.1:9080/CORE/:className/:funName',{className: '@postAuthclassName', funName: '@postAuthfunName'});
	    }
	  ]).
	  /**
	   * 角色get请求封装
	   */
	  factory('getAuthUrl', ['$resource',function($resource) {
	      return $resource('http://127.0.0.1:9080/CORE/:className/:funName',{className: '@getAuthclassName', funName: '@getAuthfunName'});
	    }
	  ]).
	  /**
	   * 兑换post请求封装
	   */
	  factory('postChangeUrl', ['$resource',function($resource) {
	      return $resource('http://127.0.0.1:9080/CREDI_CARD_CHANGE_WEB/changeserver/:className/:funName',{className: '@postChangeclassName', funName: '@postChangefunName'});
	    }
	  ]).
	  /**
	   * 兑换get请求封装
	   */
	  factory('getChangeUrl', ['$resource',function($resource) {
	      return $resource('http://127.0.0.1:9080/CREDI_CARD_CHANGE_WEB/changeserver/:className/:funName',{className: '@getChangeclassName', funName: '@getChangefunName'});
	    }
	  ])
});