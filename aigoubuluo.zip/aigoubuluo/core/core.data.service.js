'use strict';
/**
 * 创建本地数据工厂实现各个控制器中数据的交互
 * 使用方法如下：
 * 1、存储数据(工厂名称.setObject("自定义名","所需要上传的数据data")):
 *     例子：lodinDataService.setObject("demoList","我是需要共享的数据data");
 * 2、获取数据(工厂名称.getObject("自定义名")):
 *     例子：lodinDataService.getObject("demoList");
 */
define(['dataService','appModule'], function () {
	angular.module('systemApp').factory('lodinDataService',['$window',function($window) {
		 return{        
			 	//存储单个属性
		        set :function(key,value){
		          $window.localStorage[key]=value;
		        },        
		        //读取单个属性
		        get:function(key,defaultValue){
		          return  $window.localStorage[key] || defaultValue;
		        },        
		        //存储对象，以JSON格式存储
		        setObject:function(key,value){
		          $window.localStorage[key]=JSON.stringify(value);
		        },        
		        //读取对象
		        getObject: function (key) {
		          return JSON.parse($window.localStorage[key] || '{}');
		        }

		      };
	}])
	.factory('lodinDatadService',['$window',function($window) {
		 return{        
			 	//存储单个属性
		        set :function(key,value){
		          $window.localStorage[key]=value;
		        },        
		        //读取单个属性
		        get:function(key,defaultValue){
		          return  $window.localStorage[key] || defaultValue;
		        },        
		        //存储对象，以JSON格式存储
		        setObject:function(key,value){
		          $window.localStorage[key]=JSON.stringify(value);
		        },        
		        //读取对象
		        getObject: function (key) {
		          return JSON.parse($window.localStorage[key] || '{}');
		        }

		      };
	}])
	.factory('datadService',['$window',function($window) {
		 return{        
				//存储单个属性
		        set :function(key,value){
		          $window.localStorage[key]=value;
		        },        
		        //读取单个属性
		        get:function(key,defaultValue){
		          return  $window.localStorage[key] || defaultValue;
		        },       
		        //存储对象，以JSON格式存储
		        setObject:function(key,value){
		          $window.localStorage[key]=JSON.stringify(value);
		        },        
		        //读取对象
		        getObject: function (key) {
		          return JSON.parse($window.localStorage[key] || '{}');
		        }

		      };
	}]);
});

