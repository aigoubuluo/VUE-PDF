/**
 * 入口文件
 * 2017-04-15 
 */
var config = {
    baseUrl: '',           //依赖相对路径  components/domReady.min/domReady.min 
    paths: {                    //如果某个前缀的依赖不是按照baseUrl拼接这么简单，就需要在这里指出
    	/**
         * 以下为通用类组件
         * 2017-04-15 
        */ 
    	jquery:'js/jquery-1.11.1.min',
    	domReady: 'components/domReady.min/domReady.min',
    	placeholder:'components/jquery/jquery.placeholder.min.js/jquery.placeholder.min',//所有的浏览器都支持placeholder【输入框内的友好提示】，唯独IE不支持。现在我们有了这款插件，IE下终于可以支持了！(http://www.w3school.com.cn/tiy/t.asp?f=html5_input_placeholder)  依赖jquery
    	bootstrap:'components/bootstrap/dist/js/bootstrap.min',//bootstrap整体样式类组建
        angular: 'components/angular/angular',
        css: 'components/angular-css/angular-css',//路由按需加载CSS个性样式  依赖angularjs
        app:'app.config',//自定义路由器
        appModule:'app.module',//依赖模块
        angularRouter:'components/angular-route/angular-route',//angular-router 路由组建  依赖angularjs
        router:'components/angular-ui-route/angular-ui-router',//angular-UI-router 路由组建  依赖angularjs
        resource:'components/angular-resource/angular-resource',//angularjs数据交互组建  依赖angularjs
        cookies:'components/angular-cookie/angular-cookies.min',//angular-cookies组建  依赖angularjs
        sanitize:'components/angular-sanitize/angular-sanitize',//ngSanitize模块的linky过滤器编译链接(http://www.mamicode.com/info-detail-322397.html)  依赖angularjs
//        animate:'components/angular-animate/angular-animate',//$animate服务提供了基本的DOM操作功能如在DOM里插入、移除和移动元素，以及添加和删除类。这个服务是ngAnimate的核心服务，为CSS和Javascript提供了高档次的动画。(http://www.cnblogs.com/ys-ys/p/4987022.html)  依赖angularjs
        beAlert:'components/beAlert/BeAlert',//提示组件  alert  依赖jquery
        ztree:'js/ztree/jquery-ztree-all-check',//公共树组件
        echarts:'js/echarts/echarts',//图表类组件库
        ngDialog:'components/angular-ngDialog/ngDialog.min',//动态窗口
        bootstrapTable:'components/bootstrap-table/bootstrap-table',//冻结列组件
        bootstrapTableCN:'components/bootstrap-table/bootstrap-table-zh-CN',//冻结列组件汉化
        
        shim:'components/angular-file-upload/es5-shim.min',//兼容ie8 文件上传插件依赖库
        sham:'components/angular-file-upload/es5-sham.min',//兼容ie8 文件上传插件依赖库
        consolesham:'components/angular-file-upload/console-sham.min',//兼容ie8 文件上传插件依赖库
        fileUpload:'components/angular-file-upload/angular-file-upload',//文件上传插件主文件
        publicThumb:'view/public/publicThumb/public.thumb',//文件上传插件主文件-图片预览兼容IE9以上
        /**
         * 以下为自定义模块
         * 2017-04-15 
        */ 
    	dataService:'core/core.data.service',// 自定义数据工厂  创建localStorage本地缓存
    	tubehttpService:'core/core.tubehttp.service',// 自定义内管请求路径
    	businesshttpService:'core/core.businesshttp.service',// 自定义业务请求路径
    	authService:'core/core.service/auth.service',// 自定义拦截器数据工厂
    	authInterceptorService:'core/core.service/authInterceptor.service',// 自定义拦截器
    	indexRun:'core/core.service/index.run',// 初始化加载
    	pagination:'view/public/publicPagination/public.pagination',//分页
    	publicZtree:'view/public/publicZtree/public.ztree',//针对于angularjs 封装Ztree
    	publicEchart:'view/public/publicEcharts/public.echarts',//图表类组件库
    	PinyinConversion:'view/public/PinyinConversion/PinyinConversion',//汉字转化为拼音
    	VICard:'view/public/VICard/VICard',//身份证校验
    	tableCheck:'view/public/tableCheck/tableCheck',//输入框验证
    	tableFixedColumns:'components/bootstrap-table/extensions/fixed-column/js/bootstrap-table-fixed-columns',//冻结列自定义组件
    },
    shim: {                     //引入没有使用requirejs模块写法的类库。例如underscore这个类库，本来会有一个全局变量'_'。这里shim等于快速定义一个模块，把原来的全局变量'_'封装在局部，并导出为一个exports，变成跟普通requirejs模块一样
    	'jquery': {
            exports: 'jquery'
        },
        'angular': {
            exports: 'angular'
        },
        'bootstrapTable': {
        	exports: 'bootstrapTable'
        },
        'PinyinConversion': {
            deps: ['jquery']//依赖什么模块
        },
        'VICard': {
            deps: ['jquery']//依赖什么模块
        },
        'tableCheck': {
            deps: ['jquery']//依赖什么模块
        },
        'bootstrapTable': {
            deps: ['jquery']//依赖什么模块
        },
        'bootstrapTableCN': {
            deps: ['jquery','bootstrapTable']//依赖什么模块
        },
        'tableFixedColumns': {
            deps: ['jquery','bootstrapTable']//依赖什么模块
        },
        'placeholder': {
            deps: ['jquery']//依赖什么模块
        },
        'bootstrap': {
            deps: ['jquery']//依赖什么模块
        },
        'beAlert': {
            deps: ['jquery']//依赖什么模块
        },
        'ztree': {
            deps: ['jquery']//依赖什么模块
        },
        'shim': {
            deps: ['jquery']//依赖什么模块
        },
        'sham': {
            deps: ['jquery']//依赖什么模块
        },
        'consolesham': {
            deps: ['jquery']//依赖什么模块
        },
        'ngDialog': {
            deps: ['angular']//依赖什么模块
        },
        'fileUpload': {
            deps: ['angular']//依赖什么模块
        },
        'publicThumb': {
            deps: ['angular']//依赖什么模块
        },
        'angularRouter': {
            deps: ['angular']//依赖什么模块
        },
    	'router': {
            deps: ['angular']//依赖什么模块
        },
        'resource': {
            deps: ['angular']//依赖什么模块
        },
        'css': {
        	deps: ['angular']//依赖什么模块
        },
        'cookies': {
        	deps: ['angular']//依赖什么模块
        },
        'sanitize': {
        	deps: ['angular']//依赖什么模块
        },
//        'animate': {
//        	deps: ['angular']//依赖什么模块
//        },
        'pagination': {
        	deps: ['angular']//依赖什么模块
        },
        'ngThumb': {
        	deps: ['angular']//依赖什么模块
        }
        
    }
};
require.config(config);
require(['jquery','domReady','bootstrapTable','tableFixedColumns','bootstrapTableCN','placeholder','bootstrap','angular','css','app','appModule','angularRouter','router','resource','cookies','sanitize','beAlert','ztree','echarts','ngDialog','shim','sham','consolesham','fileUpload','publicThumb','publicZtree','dataService','tubehttpService','businesshttpService','authService','authInterceptorService','indexRun','pagination','publicEchart','PinyinConversion','VICard','tableCheck'],function(){
	if(!console){
        var console = {
            log:function(v){
                return v;
            }
        }
    }
   document.createElement("ng-view");
   document.createElement("ng-include");
   document.createElement("ng-disable");
   document.createElement("ng-model");
   document.createElement("ng-click");
   document.createElement("ng-repeat");
   document.createElement("ng-show");
   document.createElement("ng-if");
   document.createElement("tbl-pagination");
   document.createElement("pg");
   document.createElement("ng-class");
   document.createElement("ng-change");
   document.createElement("ng-options");
   document.createElement("ng-app");
   document.createElement("ng-readonly");
   document.createElement("ng-controller");
   document.createElement("ng-submit");
   document.createElement("ng-scope");
   angular.bootstrap(document, ['systemApp']);//这里会去执行app.js这个文件
})